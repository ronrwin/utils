package jadx.core.dex.nodes;

public interface IDexNode {

	DexNode dex();

	RootNode root();
}


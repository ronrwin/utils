package com.sonyericsson.chkbugreport;

@SuppressWarnings("serial")
/* package */ class IllegalParameterException extends RuntimeException {

    public IllegalParameterException(String string) {
        super(string);
    }

}
